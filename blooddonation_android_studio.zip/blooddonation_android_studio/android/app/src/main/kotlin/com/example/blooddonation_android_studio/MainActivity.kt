package com.example.blooddonation_android_studio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
